
Alpro Physio Clinic – One-Page Site (TailwindCDN)

Files:
- index.html        => main page (uses Tailwind via CDN)
- /assets/logo.png  => placeholder logo (replace with your official logo if desired)

Hosting:
- You can open index.html locally in a browser.
- Or upload the folder to any static host (Netlify, Vercel, GitHub Pages, etc.).

Editing:
- Update phone/email/address in the Contact section of index.html.
- Replace /assets/logo.png with your own logo file to see it in the header.

Note:
- Illustrations in Services and About use external image URLs (icons8/freepik).
  They will load as long as you have internet access.
